/**
 * 
 */

import java.util.ArrayList;

public class Array
{
	public static void main(String[] args) {
		ArrayList<Students> students = new ArrayList<Students>();
		students.add(new Students(12, "John Apple", "124 Street Rd"));
		students.add(new Students(23, "Jacob Jacobson", "125 Street Rd"));
		students.add(new Students(13, "Jingle Heimer", "126 Street Rd"));
		students.add(new Students(4, "Schmidt Frumpkin", "127 Street Rd"));
		students.add(new Students(25, "Alph Bet", "128 Street Rd"));
		students.add(new Students(46, "Bart Tweek", "129 Street Rd"));
		students.add(new Students(17, "Yaeger Gunny", "130 Street Rd"));
		students.add(new Students(78, "Mary Romeo", "131 Street Rd"));
		students.add(new Students(99, "Georgina Kalp", "132 Street Rd"));
		students.add(new Students(10, "Paula Jane", "133 Street Rd"));
		
		mergeSort(students, 0, students.size()-1);
		
		for (int i=0; i<students.size(); i++) {
			System.out.println(students.get(i));
		}
	}
	public static void mergeSort(ArrayList<Students> students, int l, int j, int x) {
		// TODO Auto-generated method stub
		int n1 = j - l + 1;
		int n2 = x - j;
		Students L[] = new Students[n1];
		Students R[] = new Students[n2];
		
		for (int a=0; a<n1; a++) 
			L[a] = students.get(l + a);
		
		for (int b=0; b<n2; b++) 
			R[b] = students.get(j + 1 + b);
			int a = 0;
			int b = 0;
			int k = l;
		
		while (a < n1 && b < n2) {
			if (L[a].compareTo(R[b])<0) {
				students.set(k, L[a]);
				a++;
			}
			else {
				students.set(k, R[b]);
				b++;
			}
			k++;
		}
		
		while (a<n1) {
			students.set(k, L[a]);
			a++;
			k++;
		}
		
		while (b<n2) {
			students.set(k, R[b]);
			b++;
			k++;
		}
	}
	
	public static void mergeSort(ArrayList<Students> students, int l, int x) {
		if (l<x) {
			int m = (l+x)/2;
			mergeSort(students, l, m);
			mergeSort(students, m+1, x);
			mergeSort(students, l, m, x);
		}
	}
}