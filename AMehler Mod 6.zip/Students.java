/**
 * 
 */
/**
 * 
 */

public class Students implements Comparable<Students>
{
	int rollno;
	String name;
	String address;
	
	public Students(int rollno, String name, String address) {
		this.rollno = rollno;
		this.name = name;
		this.address = address;
	}
	
	@Override
	public int compareTo(Students o) {
		// TODO Auto-generated method stub
		return this.rollno - o.rollno;
	}
	
	public String toString() {
		return "Rollno: " + rollno + "\nName: " + name + "\nAddress: " + address;
	}
}